package com.visphos.holo01

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 9, 20)
        window.navigationBarColor = Color.rgb(5, 9, 20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(26), dp(30), dp(26), dp(30))
            setBackgroundColor(Color.rgb(5, 9, 20))
        }
        val title = TextView(this).apply {
            text = "HOLO.01"
            textSize = 34f
            setTextColor(Color.rgb(91, 225, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "SPATIAL CONTROL SYSTEM  /  PROTOTYPE 0.1\n\nDeploy creates a floating 3D interface above supported apps."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(28))
        }
        val deploy = Button(this).apply {
            text = "DEPLOY HOLO.01"
            setOnClickListener { deployOverlay() }
        }
        val access = Button(this).apply {
            text = "ENABLE PHONE CONTROL"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val note = TextView(this).apply {
            text = "This first native build tests the overlay and 3D scene. Hand tracking and gesture-to-action mapping are not yet implemented. The interface is a screen-based 3D illusion, not light physically suspended in air."
            textSize = 12f
            setTextColor(Color.rgb(160, 174, 195))
            gravity = Gravity.CENTER
            setPadding(0, dp(26), 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(deploy, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(access, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun deployOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        startForegroundService(Intent(this, HoloOverlayService::class.java))
    }
}
