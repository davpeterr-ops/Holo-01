package com.visphos.holo01

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

class HoloOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("holo_overlay", "HOLO.01 overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            val notification = Notification.Builder(this, "holo_overlay")
                .setContentTitle("HOLO.01 is deployed")
                .setContentText("Floating interface is active")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
            startForeground(101, notification)
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun showOverlay() {
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/holo.html")
        }
        val frame = FrameLayout(this)
        frame.addView(web, FrameLayout.LayoutParams(-1, -1))
        val close = android.widget.TextView(this).apply {
            text = "×"
            textSize = 26f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(0xAA102033.toInt())
            gravity = Gravity.CENTER
            setOnClickListener { stopSelf() }
        }
        frame.addView(close, FrameLayout.LayoutParams( dp(42), dp(42), Gravity.TOP or Gravity.END))
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(dp(300), dp(390), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(70) }
        frame.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; return false }
                if (e.action == MotionEvent.ACTION_MOVE && e.pointerCount == 1 && e.rawY-downY > dp(12)) {
                    params.x = startX + (e.rawX-downX).toInt(); params.y = startY + (e.rawY-downY).toInt()
                    try { wm.updateViewLayout(frame, params) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        })
        overlay = frame
        wm.addView(frame, params)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }; overlay=null; super.onDestroy() }
}
