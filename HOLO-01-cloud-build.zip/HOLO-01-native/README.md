# HOLO.01 — Native Android prototype 0.1

This is the first native Android prototype source project. It is not itself an APK.

## What this prototype currently does
- Native Android launch screen with a DEPLOY button.
- Requests Android's normal "Display over other apps" permission.
- Starts a foreground service and displays a movable floating interface above other apps.
- Shows a 3D-style scene in the floating panel.
- Provides an Accessibility Service declaration as a foundation for later explicit phone-control features.

## What is not implemented yet
- Live camera hand tracking.
- Hand gestures mapped to phone actions.
- Full hands-free control of arbitrary apps.
- A physical hologram or image suspended in open air. The current graphics are displayed on the phone screen.

## Build an APK without installing Android Studio
This project includes a GitHub Actions cloud-build workflow at `.github/workflows/android-apk.yml`. GitHub's hosted runner installs Java, Android SDK packages and Gradle, then builds a debug APK. The workflow is configured to run on pushes to `main` and can also be started manually.

### Steps using your phone's Chrome browser
1. Download and extract the ZIP.
2. Sign in to GitHub and create a **new empty repository** named `HOLO-01` (do not add a README or licence during repository creation).
3. Open the new repository and choose **Add file → Upload files**.
4. Upload the *contents* of the extracted `HOLO-01-native` folder, including the hidden `.github` folder. If the mobile file picker hides dot-folders, use GitHub's web interface in Desktop site mode and make sure `.github/workflows/android-apk.yml` is included. The workflow must end up at that exact path in the repository.
5. Commit the upload to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build HOLO.01 APK**, then **Run workflow** if it has not already started.
7. Wait for the run to finish. A green check means the build job completed. Open the run and download the `HOLO-01-debug-apk` artifact. GitHub packages this artifact as a ZIP containing `app-debug.apk`.
8. Extract `app-debug.apk` on your phone and open it to install. Android may ask you to allow installation from that browser or file manager; only allow it for the file you built from your own repository.

GitHub Actions usage limits depend on repository visibility and account plan. Public repositories generally have free standard-runner minutes; private repositories have plan limits. No Android Studio installation is needed for this cloud workflow.

## First device test
1. Open HOLO.01.
2. Tap **DEPLOY HOLO.01**.
3. Grant **Display over other apps** permission when Android asks.
4. Return to HOLO.01 and tap DEPLOY again.
5. Confirm the floating panel appears above another app. Use × to close it.

The Accessibility button opens Android Accessibility settings. This prototype does not yet perform screen taps or swipes from hand gestures. Do not enable accessibility unless you are intentionally testing the feature and understand the permission.

## Technical notes
- Application ID: `com.visphos.holo01`
- Minimum Android version: Android 8.0 (API 26)
- Compile SDK: 35
- The build workflow uses JDK 17 and Gradle 8.9 with Android Gradle Plugin 8.7.3.
- The first build requires internet access to download build dependencies.
